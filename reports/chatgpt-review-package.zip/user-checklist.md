# ユーザー確認チェックリスト

## 自動検証済み

- [x] バックアップZIPの整合性を確認
- [x] `npm ci` が成功
- [x] `npm run build` が成功
- [x] 生成物のHTML/CSSローカル参照が全件成立
- [x] 主要6ページのブラウザ表示でコンソールエラーなし
- [x] トップカードの位置がバックアップと一致
- [x] ローカル直下版のビジュアル6ページを公開ビルドのテンプレートに統一
- [x] 公開ビルドのCSS資産ハッシュがローカル直下版と一致
- [x] カーソルの重複初期化を除去し、1組の生成へ統一
- [x] push後の公開6ページで直下版のHTML・JavaScript構成を確認
- [x] 公開CSSのSHA-256がローカル直下版と一致

## ユーザー確認が必要

- [ ] 実際の公開URLでトップの背景・カード・アニメーションを確認
- [ ] 実機スマートフォンで表示とスクロールを確認
- [ ] ヘッダーメニュー、言語切替、ギャラリーリンクを操作
- [ ] ヒアリング画面で回答を進め、送信前の確認まで操作
- [ ] Contactフォームは送信せず、入力・バリデーション表示だけ確認
- [ ] 外部画像が公開環境のCSPで許可されるか確認
- [ ] Pages再生成後、公開URLの表示がローカル直下版と一致することを確認
- [ ] 公開URLとローカルURLのカーソルが1組ずつで、ホバー表示も一致することを確認

## 戻し方

Gitで今回のコミットを親コミットへ戻せば、今回の修正をまとめて取り消せる。作業中に保存した元バックアップは削除していない。

## Responsive Typography Check

- [ ] 主要6ページを320px、390px、768px、1024px、デスクトップ幅で確認する。
- [ ] 見出し・本文・リンクの階層と、既存の大きいデスクトップ値が保たれていることを確認する。
- [ ] 日本語・英語の切れ、意図しない改行、横スクロールがないことを確認する。
- [ ] メニュー、フッター、モーダル、フォーム、表、タイムライン、キャプション、ページネーションを確認する。
- [ ] 公開URLをPages再生成後に強制再読み込みして確認する。
- [ ] 実機Safari/iOS/Android、物理マウス・タッチでの確認結果を記録する。

## Header / Footer追加確認

- [ ] `header-container`と`footer-container`を残した状態で表示を確認する。
- [ ] ルートページのHTMLに`js/footer.js`の読み込みがないことを確認する。
- [ ] `menu.js`のみでフッターが1件表示され、5リンクと年表示が出ることを確認する。

## Responsive Width Check

- [ ] 主要ページを320px、390px、600px、768px、1024px、デスクトップ幅で確認する。
- [x] ローカル390px幅でBiography本文が折り返されることを確認する。
- [x] ローカル390px幅でContactフォームが固定幅で横溢れしないことを確認する。
- [ ] ギャラリーモーダル、フッター、メニュー、matchingフォームを確認する。
- [ ] 実機Safari/iOS/Androidとタッチ操作を確認する。

## 2026-09-07 JavaScript Integration Check

- [x] Confirm p5 is retained because the existing VANTA.TRUNK background depends on it.
- [x] Confirm the six root pages use common cursor, loading, header, and footer behavior through `menu.js`.
- [x] Confirm gallery sidebar loading and category setup work through `page-nation.js`.
- [ ] Repeat the checks on the public pages after deployment and perform physical-device acceptance.
