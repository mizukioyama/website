# 既知の課題

- Webpackは元画像をそのまま出力するため、成果物が大きい。画像最適化はNode環境に合うツールへ置き換える別作業とする。
- Browserslistのブラウザデータが古いという警告が出る。依存更新は表示差分を生む可能性があるため今回は実施していない。
- `npm ci` 後の監査で既存依存に 33 件（low 5、moderate 13、high 13、critical 2）の警告がある。自動アップデートは今回の表示保全範囲外。
- RippleはAPIが利用可能なときだけ動作し、未対応環境では安全に停止する。WebGL対応環境での演出確認は未実施。
- カテゴリ別・年別の専用HTMLはバックアップにも存在しなかったため、暫定的に既存の `gallery.html` へ遷移する。
- 外部GitHub画像とGoogleフォーム送信は、ネットワーク・CSP・サービス側状態に依存するため、ローカル静的検証だけでは完了判定できない。
- ブラウザ自動検証は実効ビューポート1280x720で実施した。実機スマートフォンの表示、キーボード操作、Safari固有差分は未確認。
- ルートの`header-container`と`footer-container`は、`js/menu.js`が生成したDOMを挿入するために必要である。削除する場合は、JS側でマウント位置を作成する別変更が必要になる。
- `js/footer.js`は互換シムとして残している。削除には明示的な削除承認が必要で、ルートページからは読み込まれていない。
- `js/page-nation.js`はブラウザで`require("fs")`を実行するため、ギャラリーページで`require is not defined`が発生する。今回のヘッダー／フッター統合では変更していない。
- GitHub Pagesの再生成後に公開ファイル同期は確認済み。ブラウザキャッシュやCDNの状態によって切替直後に旧成果物が見える場合は、強制再読み込みで確認する。
- 今回の生成版をブラウザで再表示する確認は、Macがロック中だったため未実施。Macのロック解除後に公開6ページとカーソルを確認する。
- `src/public/js/menu.js`と`src/public/js/footer.js`には旧ページ向けのfetch実装が残るが、今回のビジュアル6ページは直下版の`js/menu.js`を使い、`footer.js`を読み込まない。将来の旧ページ整理は別作業とする。

## 2026-09-06 Responsive Typography Push

- フォントサイズは静的検査で`clamp()`化したが、全ページを実機Safari/iOS/Androidで確認した結果ではない。
- フォント読込、ブラウザのズーム、フォールバックフォント、デバイスピクセル比により、改行位置や実寸が変わる可能性がある。
- レガシー・テスト用ファイルは対象外として固定値を残している。変更する場合は別スコープで確認する。
- GitHub PagesのActions完了後に、公開6ページの実画面とキャッシュ切替を確認する必要がある。

## 2026-09-07 Responsive Width Hardening

- `scripts/check-generated.cjs` is absent, so generated-output validation remains unavailable.
- The working tree contains unrelated generated changes, deletions, and untracked files; they were excluded from this scoped commit.
- Physical Safari/iOS/Android, touch input, and post-deployment public visual acceptance remain pending.
- Legacy/test-only width files remain unchanged because they are outside the active page/build path.

## 2026-09-07 JavaScript Integration

- `p5.min.js` is required by `vanta.trunk.min.js` for the artist statement, biography, and contact backgrounds.
- `js/cursor.js`, `js/loading.js`, and `js/side.js` remain available after their runtime logic was integrated; they were not deleted without explicit approval.
- Public deployment and physical Safari/iOS/Android or touch acceptance remain pending.
- The local reproduction build is blocked by a missing `node_modules/@fortawesome/fontawesome-free/webfonts` directory; dependency installation/CI build verification remains pending.
